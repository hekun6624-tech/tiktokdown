# TikDown Android project (prototype 1.0)

A minimal, ad-free Android app shell. It accepts direct, publicly accessible video-file URLs (MP4/WEBM/MOV) and downloads them with Android DownloadManager into `Download/TikDown`. It also accepts Android Sharesheet text intents.

## Important limitation
TikTok share-page URLs are not direct media-file URLs. This prototype deliberately does **not** scrape TikTok pages, bypass access controls, or claim to remove watermarks. A reliable TikTok URL resolver requires a lawful/authorized source or service and must be integrated separately. Watermark removal is not implemented. Only save content you own or are authorized to download and process.

## Build APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder (`TikDown`) in Android Studio.
3. Allow Gradle sync; use JDK 17.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be under `app/build/outputs/apk/debug/`.

Application ID: `com.tikdown.app`
Min Android: 6.0 (API 23)
Target SDK: 35

This workspace did not have Android SDK/Gradle installed, so an APK could not be compiled here. The project source is provided for building in Android Studio.
