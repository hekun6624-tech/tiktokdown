package com.tikdown.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    private EditText urlInput;
    private TextView status;
    private int blue = Color.rgb(37, 99, 235);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(248,250,252));
        getWindow().setNavigationBarColor(Color.rgb(248,250,252));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        buildUi();
        handleShare(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent); handleShare(intent);
    }

    private void handleShare(Intent intent) {
        if (intent != null && Intent.ACTION_SEND.equals(intent.getAction())) {
            CharSequence shared = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (shared != null) urlInput.setText(shared.toString().trim());
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(248,250,252));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22), dp(30), dp(22), dp(24));
        scroll.addView(root); setContentView(scroll);

        TextView brand = new TextView(this); brand.setText("TikDown"); brand.setTextSize(30); brand.setTypeface(null, Typeface.BOLD); brand.setTextColor(Color.rgb(15,23,42)); root.addView(brand);
        TextView tagline = new TextView(this); tagline.setText("干净、简单、没有广告"); tagline.setTextSize(14); tagline.setTextColor(Color.rgb(100,116,139)); addGap(root, 5); root.addView(tagline);

        TextView heading = new TextView(this); heading.setText("下载视频"); heading.setTextSize(20); heading.setTypeface(null, Typeface.BOLD); heading.setTextColor(Color.rgb(15,23,42)); addGap(root, 34); root.addView(heading);
        TextView hint = new TextView(this); hint.setText("粘贴你有权下载或保存的视频直链（MP4 / WEBM）"); hint.setTextSize(13); hint.setTextColor(Color.rgb(100,116,139)); addGap(root, 7); root.addView(hint);

        urlInput = new EditText(this); urlInput.setSingleLine(false); urlInput.setMinLines(2); urlInput.setTextSize(14); urlInput.setHint("https://example.com/video.mp4"); urlInput.setPadding(dp(14),dp(12),dp(14),dp(12)); urlInput.setBackground(round(Color.WHITE, Color.rgb(226,232,240), 14)); LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2); ip.topMargin=dp(14); root.addView(urlInput, ip);

        Button paste = button("粘贴链接", false); LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(48)); pp.topMargin=dp(12); root.addView(paste, pp);
        paste.setOnClickListener(v -> { ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE); if(cm!=null && cm.hasPrimaryClip()){ ClipData d=cm.getPrimaryClip(); if(d!=null && d.getItemCount()>0 && d.getItemAt(0).coerceToText(this)!=null) urlInput.setText(d.getItemAt(0).coerceToText(this)); } });

        Button download = button("开始下载", true); LinearLayout.LayoutParams dpv = new LinearLayout.LayoutParams(-1, dp(52)); dpv.topMargin=dp(12); root.addView(download, dpv); download.setOnClickListener(v -> startDownload());

        status = new TextView(this); status.setText("提示：目前此版本支持可直接访问的视频文件链接。TikTok 分享页链接需要额外的合规解析服务，不能直接当作视频文件下载。"); status.setTextSize(13); status.setTextColor(Color.rgb(71,85,105)); status.setPadding(dp(14),dp(14),dp(14),dp(14)); status.setBackground(round(Color.rgb(239,246,255), Color.rgb(219,234,254), 12)); LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2); sp.topMargin=dp(18); root.addView(status,sp);

        TextView privacy = new TextView(this); privacy.setText("隐私说明\n不收集账号、密码或浏览记录；下载任务由 Android 系统 DownloadManager 处理。请仅下载你拥有权利或已获授权保存的内容，并遵守平台规则及当地法律。"); privacy.setTextSize(12); privacy.setTextColor(Color.rgb(100,116,139)); addGap(root, 28); root.addView(privacy);
    }

    private void startDownload() {
        String raw=urlInput.getText().toString().trim();
        if(raw.isEmpty()){ show("请先粘贴视频文件链接。"); return; }
        Uri uri;
        try { uri=Uri.parse(raw); } catch(Exception e){ show("链接格式不正确。"); return; }
        String scheme=uri.getScheme(); String host=uri.getHost();
        if(!("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) || host==null){ show("请输入有效的 HTTP 或 HTTPS 链接。"); return; }
        String path=uri.getPath()==null?"":uri.getPath().toLowerCase();
        if(host.toLowerCase().contains("tiktok.com") || !(path.endsWith(".mp4") || path.endsWith(".webm") || path.endsWith(".mov"))){
            show("这是网页分享链接或无法确认的视频地址。本版本暂不解析 TikTok 页面链接；请使用你有权保存的直接视频文件链接。不会伪称下载成功。"); return;
        }
        try {
            DownloadManager.Request req=new DownloadManager.Request(uri);
            req.setTitle("TikDown 视频下载"); req.setDescription("正在保存到 Download/TikDown");
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "TikDown/video_"+System.currentTimeMillis()+ (path.endsWith(".webm")?".webm":path.endsWith(".mov")?".mov":".mp4"));
            DownloadManager dm=(DownloadManager)getSystemService(DOWNLOAD_SERVICE); dm.enqueue(req);
            show("下载任务已提交。完成后可在手机的 Download/TikDown 文件夹查看。");
            ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(urlInput.getWindowToken(),0);
        } catch(Exception e){ show("无法启动下载，请检查链接是否可公开访问。"); }
    }

    private void show(String msg){ status.setText(msg); }
    private void addGap(LinearLayout l,int h){ View v=new View(this); l.addView(v,new LinearLayout.LayoutParams(1,dp(h))); }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private GradientDrawable round(int color,int stroke,int radius){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(1),stroke); return d; }
    private Button button(String text, boolean primary){ Button b=new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(15); b.setTypeface(null,Typeface.BOLD); b.setTextColor(primary?Color.WHITE:Color.rgb(30,41,59)); b.setBackground(round(primary?blue:Color.WHITE,primary?blue:Color.rgb(226,232,240),13)); return b; }
}
